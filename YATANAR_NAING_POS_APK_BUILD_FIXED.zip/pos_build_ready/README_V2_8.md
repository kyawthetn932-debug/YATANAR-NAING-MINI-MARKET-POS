# YATANAR NAING POS V2.8

V2.8 builds on V2.7 and adds Owner-controlled Store Settings / Receipt Customization.

## Added
- Store name, address and phone
- Store logo selection and persistent URI storage
- Receipt thank-you note and return-policy text
- Currency label
- Background color HEX and font-size settings stored for future UI theming
- Owner-only settings screen
- Store name shown on dashboard
- Receipt header uses saved store name/address/phone
- Receipt footer uses saved return-policy and thank-you text
- Backup/restore now includes store settings
- Database migration 13 -> 14
- Version code 8 / version name 2.8

## Notes
- Logo is stored and ready for later graphical receipt/thermal-printer rendering; V2.8 text receipts do not yet render the logo image.
- Background/font/menu-style values are stored as customization foundations; full visual theme application will be completed in a later UI pass.
- Real-time cloud sync, payment APIs, model-specific thermal printing, security hardening, final APK/AAB build and Play Store publishing remain later stages.
