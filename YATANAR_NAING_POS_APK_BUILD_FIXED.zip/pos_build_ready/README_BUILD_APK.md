# YATANAR NAING MINI MARKET POS — APK Build Package

This package is prepared for building an installable Android APK with GitHub Actions.

## What it builds
- Android Debug APK
- Application ID: com.yatanarnaing.pos
- Target SDK: 35
- Minimum SDK: 23
- Version: 4.0 (versionCode 16)

## Important
This package is source code, not an APK. The included GitHub Actions workflow builds the APK automatically on GitHub using Java 17, Android SDK 35 and Gradle 8.7.

After a successful build, download the artifact named:
`YATANAR-NAING-MINI-MARKET-POS-debug-apk`

The resulting APK can be installed on the Vivo Y28 for testing.
