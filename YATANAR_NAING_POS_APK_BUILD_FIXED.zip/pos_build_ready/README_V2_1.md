# YATANAR NAING POS V2.1

## 👥 Staff Management + Detailed Permissions

V2.1 builds on V2.0.

### New
- Owner can create multiple Staff accounts.
- Each Staff account has its own username and PIN.
- Owner can choose permissions for:
  - Sales / အရောင်း
  - Product & Stock / ပစ္စည်းစာရင်း
  - Invoice OCR / ကုန်အဝင်
  - Debt / အကြွေး
- Staff can only open operational modules that are allowed for their account.
- Denied permission attempts are recorded in Audit Log.
- Owner-only modules remain protected.
- Staff list shows each account and its active permissions.
- Default Staff account remains Staff / 0000 with the four operational permissions enabled.
- PINs remain SHA-256 hashed.
- Database version: 8; V2.0 databases upgrade to V2.1.

## Important
This is a source project ZIP, not an APK. Android SDK/Gradle build tools are not available in the current environment, so APK compilation is not included.
