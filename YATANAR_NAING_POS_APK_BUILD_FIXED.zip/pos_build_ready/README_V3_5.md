# YATANAR NAING MINI MARKET POS — V3.5

V3.5 focuses on Owner Cloud Account, multi-device identity, remote dashboard, cloud status, device/sync activity, conflict protection, and local backup/restore.

## App additions
- Owner-only Cloud Account Login/Register.
- Device ID based on Android device identity and Device Name.
- Store ID + Device ID are retained for each installation.
- Cloud Account token is stored locally for authenticated sync.
- Cloud Sync / Pull remains protected by HTTPS and optimistic conflict checks.
- Remote Dashboard reads cloud summary without replacing the local database.
- Device Activity / Sync History screen.
- Existing Local Backup/Restore remains available.

## Cloud server starter
`cloud_server/` now supports:
- `POST` JSON `{action:"register",email,password,store_id,device_id,device_name}`
- `POST` JSON `{action:"login",email,password,store_id,device_id,device_name}`
- Authenticated `POST` upload
- Authenticated `GET` pull
- Authenticated `GET?action=summary` for remote dashboard
- Authenticated `GET?action=devices` for device activity data

This is still a starter deployment, not a hosted service. Before production, deploy on a real HTTPS PHP 8+ server and change the secret in `config.php`. For a commercial/production release, add database storage, rate limiting, account recovery, email verification, encrypted backups, monitoring and server backups.
