# YATANAR NAING POS V2.3

## Cloud / Backup Sync foundation
- Owner-only Sync Center is available from `⋮ Menu`.
- Store ID and Device Name can be saved.
- Full POS database backup can be exported as JSON through Android file picker.
- JSON backup can be restored on another phone running the same/newer POS version.
- Sync metadata records the store/device and last backup/restore time.
- Audit Log records backup export/import and sync setting changes.

### Important
V2.3 is the offline backup/multi-device transfer foundation. It is **not yet an automatic Internet cloud synchronization service**. Real-time remote viewing and automatic sync require a cloud backend/account and secure authentication, which will be implemented in a later cloud version.

## Upgrade
Database version: 9. Existing V2.2 databases upgrade automatically.
