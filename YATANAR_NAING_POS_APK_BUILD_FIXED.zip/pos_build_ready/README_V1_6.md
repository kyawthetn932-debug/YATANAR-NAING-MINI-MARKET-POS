# YATANAR NAING POS V1.6

V1.6 expands Sales POS:
- Barcode/Product Code lookup
- Stock sufficiency check before adding to cart
- Customer name + phone fields
- Discount in Ks
- Cash / WavePay / KBZPay / Debt payment selection
- Debt requires customer name and records paid=0, remaining=total
- Sale records store customer, phone, discount, paid, remaining
- Stock decreases only after successful sale save
- Receipt preview with store name, customer, phone, payment, subtotal, discount, total, change/remaining and Myanmar thank-you/no-return notes
- Existing V1.5 Product/Stock, Invoice OCR/Stock-In and Pricing features retained.
- Database upgraded to version 5.

This is a source project ZIP. APK compilation is not included because Android SDK/Gradle tooling is not installed in the current build environment.
