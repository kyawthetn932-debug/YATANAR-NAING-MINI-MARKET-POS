# YATANAR NAING POS V2.6

## Barcode + Product Photo Upgrade
- Product master supports Camera/Gallery product photos.
- Camera product photo is saved into Android Pictures/YATANAR_NAING_POS and its URI is stored with the product.
- Product records now have a photo_uri field.
- Sales screen has Camera Barcode Scan using Google ML Kit Barcode Scanning; scanned value is placed into the Barcode/Product Code field for the normal stock/price lookup flow.
- Product screen also includes a barcode scan button.
- Existing V2.5 data migrates to database version 12; product photo column is added non-destructively.
- Existing receipt, printer, contacts, cloud backup, reports, debt, pricing and permission foundations are retained.

Note: this source project still needs an Android SDK/Gradle environment to build an APK/AAB.
