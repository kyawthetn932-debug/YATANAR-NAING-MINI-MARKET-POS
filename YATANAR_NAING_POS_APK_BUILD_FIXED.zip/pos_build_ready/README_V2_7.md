# YATANAR NAING POS V2.7

## 📦 Stock Management / ကုန်အဝင်အထွက်
- Manual Stock In / ကုန်အဝင်
- Manual Stock Out / ကုန်အထွက်
- Stock Adjustment / လက်ကျန်ညှိခြင်း
- Stock History / အဝင်အထွက်မှတ်တမ်း
- Before → After quantity tracking
- Low Stock Alert integration
- User + date/time audit information
- Owner-only access for manual movement and history
- Database upgrade version 13

V2.6 is the base version. Keep earlier ZIP versions as backups.
