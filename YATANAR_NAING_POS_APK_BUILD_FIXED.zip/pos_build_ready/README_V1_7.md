# YATANAR NAING POS V1.7

V1.7 adds a dedicated Debt Ledger and debt settlement flow.

- Debt sales are listed with customer, phone, total, paid and remaining.
- Search by customer name or phone.
- Record partial or full debt payments.
- Debt payment history is stored in `debt_payments`.
- Settlement updates the original sale's paid/remaining amounts.
- A debt-payment receipt is shown after settlement.
- Keeps V1.6 Sales, Product/Stock, Pricing and Invoice OCR foundations.
- Dates displayed as DD/MM/YYYY in the debt ledger.

Note: This is an Android source project ZIP, not a compiled APK. The current environment does not include Android SDK/Gradle build tools.
