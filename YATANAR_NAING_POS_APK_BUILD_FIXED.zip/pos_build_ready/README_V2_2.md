# YATANAR NAING POS V2.2

## Printer + Barcode Scanner
- Receipt dialog now has Print action using Android Print Framework.
- Printer module opens Android Bluetooth Settings for Bluetooth printer pairing.
- Hardware barcode scanners that behave like a USB/Bluetooth keyboard can scan into the Sales barcode field; Enter automatically triggers Add.
- Barcode Sticker Print module prepares printable sticker sheets with product name, barcode and price.
- Last receipt can be printed again from the Printer module.
- Staff must have Sales permission to use the Printer module; Owner is allowed.

## Notes
- Actual Bluetooth/USB thermal-printer command languages (ESC/POS) and label-printer-specific barcode graphics are hardware-specific and can be added after the exact printer models are known.
- Android Print Service must be installed/enabled for system printing.
