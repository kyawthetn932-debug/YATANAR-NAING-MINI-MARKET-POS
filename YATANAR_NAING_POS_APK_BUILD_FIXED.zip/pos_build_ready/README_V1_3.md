# YATANAR NAING POS — V1.3

မနေ့က V1.2 အခြေခံမှ ဆက်တည်ဆောက်ထားသည်။

## အသစ်
- 📷 အဝယ်ဘောက်ချာ Camera
- 🖼️ Gallery မှ invoice ရွေးခြင်း
- OCR (Google ML Kit Text Recognition)
- Supplier အမည် + ဘောက်ချာပါ ဖုန်းနံပါတ် + DD/MM/YYYY
- OCR စာသားကို ပြန်စစ်ပြီးမှ မှတ်တမ်းတင်နိုင်ခြင်း
- Invoice record database
- အရင် Product/Stock/Barcode/Sales/Payment/Contact အခြေခံများ ဆက်ပါဝင်

## နောက်အဆင့်
OCR product rows ကို Product database/Category/Stock-In နှင့် တကယ်ချိတ်ပြီး Qty + Purchase Price ကို အလိုအလျောက်ထည့်မည်။ ထို့နောက် transport cost allocation → receipt/printer → debt/report → owner lock/audit → cloud သွားမည်။
