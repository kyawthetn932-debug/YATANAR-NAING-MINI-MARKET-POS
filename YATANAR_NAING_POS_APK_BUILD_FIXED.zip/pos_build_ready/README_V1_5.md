# YATANAR NAING POS V1.5

V1.5 adds the Pricing / ဈေးနှုန်းသတ်မှတ်ခြင်း module.

- Select product by barcode.
- Enter batch quantity, unit purchase price, transport cost and other cost.
- Batch transport/other cost is allocated per unit by quantity.
- Enter profit percentage and calculate recommended sale price.
- Manual sale-price override is supported.
- Saving updates the selected product purchase and sale prices.
- DD/MM/YYYY remains the project date convention.
- V1.4 OCR / invoice stock-in, product stock, barcode, sales, payment recording and contacts remain included.

Note: this is an Android source project ZIP. This environment does not currently include Android SDK/Gradle, so no APK is claimed here.
