# YATANAR NAING MINI MARKET POS — V3.0

V3.0 is the production-hardening foundation continued from V2.9.

## Added / improved
- Version code/name updated to 10 / 3.0.
- Cash tendered and change amount are stored in the sales database, not only receipt text.
- Cash tendered and change are included automatically when receipts are rebuilt/reprinted.
- Database migration added for existing V2.x installations without deleting existing sales.
- Existing Owner/Staff permissions, audit log, store settings, backup foundation, stock movement, barcode/photo, OCR, pricing, sales, debt, reports, demand analysis and receipt history are retained.

## Production limitations still remaining
- Cloud is still backup/sync foundation, not a live Internet backend.
- WavePay/KBZPay are recorded payment methods; direct API payment needs merchant/provider credentials and approval.
- Thermal/ESC-POS printing is not yet model-specific.
- Barcode sticker printing is still a foundation and needs a printer-specific implementation for actual barcode graphics.
- Signed APK/AAB build and Play Store publishing are still deployment steps.

## Safety
- No destructive database reset was added for V3.0 migration.
- Keep the previous V2.9 ZIP as a backup before testing V3.0.
