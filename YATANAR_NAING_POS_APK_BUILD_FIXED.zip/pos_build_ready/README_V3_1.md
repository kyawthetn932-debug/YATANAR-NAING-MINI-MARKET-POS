# YATANAR NAING MINI MARKET POS — V3.1

V3.1 continues from V3.0 as a production-hardening release.

## Added / improved
- Version code/name updated to 11 / 3.1.
- Owner Dashboard: today's sales count, sales total, received amount, debt remaining, product count, low-stock count and today's best-selling product.
- Data Integrity Check for missing barcodes, negative stock, invalid sales amounts and duplicate-barcode records.
- Added a `sync_queue` database foundation so future secure Internet cloud synchronization can track pending changes without changing the existing POS data model.
- Backup export/import now includes the sync queue table.
- Fixed PIN change so it updates the currently logged-in account only; changing one staff PIN no longer changes every staff account.
- Database migration raised safely to version 16.
- Existing sales, stock, OCR, pricing, barcode/photo, debt, reports, demand analysis, contacts, receipts, staff permissions, owner settings and backup features retained.

## Important limitation
V3.1 still does **not** claim live Internet cloud sync. A real remote owner dashboard needs a secure server/backend, authentication and API connection. WavePay/KBZPay direct API and model-specific ESC/POS hardware integration also remain deployment/provider-dependent.

## Safety
- No destructive reset was added to the V3.1 migration.
- Keep V3.0 as a backup before installing/testing V3.1.
