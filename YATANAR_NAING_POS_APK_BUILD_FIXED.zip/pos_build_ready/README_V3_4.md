# YATANAR NAING POS V3.4

V3.4 extends V3.3 with safer Cloud Sync conflict protection.

## New
- ☁️ Cloud upload uses optimistic concurrency (`X-Client-Synced-At`).
- 🛑 Server returns HTTP 409 instead of overwriting newer cloud data.
- ⚠️ Cloud Pull checks whether the local database changed since its last successful sync and asks for confirmation before replacing local data.
- 🔐 Cloud sync remains HTTPS-only and token-protected.
- 💾 Local synced payload hash and cloud update timestamp are stored for conflict detection.
- 📋 Audit log records normal and force-approved cloud pulls.
- Database version 18 / app version 3.4 (versionCode 14).

## Important
V3.4 is safer than V3.3, but it is still a cloud-backup/sync architecture, not a finished production SaaS backend. The server starter still stores encrypted-in-transit but plaintext-at-rest JSON. Production should use a real database, encryption at rest, account-based authentication, per-device authorization, rate limiting, automated backups, monitoring, and privacy/security review.

Never upload to a server over HTTP. Keep offline backups before major restores.
