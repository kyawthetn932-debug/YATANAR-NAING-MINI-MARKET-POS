# YATANAR NAING MINI MARKET POS — FINAL RELEASE 1.0

Base: V3.5
Android versionName: 4.0

## Included POS functions
- Sales / အရောင်း
- Stock In/Out, stock history and low-stock alert
- Product photo from Camera/Gallery
- Barcode scan and duplicate-barcode protection
- Purchase invoice OCR and editable stock-in rows
- Pricing and profit calculation
- Customer / Supplier / Contacts with callable phone numbers
- Debt ledger and settlement
- Cash / WavePay / KBZPay / Debt payment records
- Cash tendered and change
- Receipt preview, history and reprint
- Reports / Profit & Loss
- Demand / sales analysis
- Owner / Staff accounts, permissions and audit log
- Store settings, logo, address, phone and receipt text
- Local JSON backup / restore
- Cloud account, Store ID, Device ID, sync status, activity and conflict protection
- Remote cloud summary foundation

## Release status
This package is the consolidated Final Release development package. It is NOT an already signed APK/AAB and it is NOT a hosted cloud service.

Before public Play Store release, the following real-world steps remain mandatory:
1. Build with a current Android SDK/Gradle environment.
2. Run device testing on Vivo Y28 and other target devices.
3. Deploy the cloud server on a real HTTPS host with a production database, secure secrets, rate limiting, backups, account recovery and monitoring.
4. Test the exact receipt printer, barcode scanner and barcode-label printer models to be supported.
5. Obtain/verify any required WavePay/KBZPay merchant API access before enabling direct API payments.
6. Perform security, backup/restore, migration, offline/online and crash testing.
7. Create a signed release AAB, prepare Play Store privacy/data-safety materials, screenshots and listing, then publish through Google Play Console.

Keep V3.5 as the rollback/base-development backup until the release has passed these tests.
