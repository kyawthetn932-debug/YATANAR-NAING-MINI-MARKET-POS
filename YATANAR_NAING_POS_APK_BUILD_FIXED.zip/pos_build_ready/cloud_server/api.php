<?php
require __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');
if (!is_dir(POS_DATA_DIR)) { mkdir(POS_DATA_DIR, 0750, true); }

function b64u($s){return rtrim(strtr(base64_encode($s), '+/', '-_'), '=');}
function ub64($s){return base64_decode(strtr($s, '-_', '+/')) ?: '';}
function issue_token($email){$h=b64u(json_encode(['alg'=>'HS256','typ'=>'POS']));$p=b64u(json_encode(['email'=>$email,'exp'=>time()+86400*30]));$sig=b64u(hash_hmac('sha256',$h.'.'.$p,POS_CLOUD_TOKEN,true));return $h.'.'.$p.'.'.$sig;}
function account_file(){return POS_DATA_DIR.'/accounts.json';}
function accounts(){if(!file_exists(account_file()))return []; $x=json_decode(file_get_contents(account_file()),true);return is_array($x)?$x:[];}
function save_accounts($a){file_put_contents(account_file(),json_encode($a,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),LOCK_EX);}
function bearer(){ $t=$_SERVER['HTTP_AUTHORIZATION']??''; return preg_replace('/^Bearer\s+/i','',$t); }
function auth_account(){
  $t=bearer();
  if($t!=='' && hash_equals(POS_CLOUD_TOKEN,$t)) return ['email'=>'__MASTER__','master'=>true];
  $p=explode('.',$t); if(count($p)!==3)return null;
  $sig=b64u(hash_hmac('sha256',$p[0].'.'.$p[1],POS_CLOUD_TOKEN,true)); if(!hash_equals($sig,$p[2]))return null;
  $data=json_decode(ub64($p[1]),true); if(!is_array($data)||($data['exp']??0)<time())return null;
  return ['email'=>$data['email']??'','master'=>false];
}
function store_key(){ $store=trim($_SERVER['HTTP_X_STORE_ID']??''); if($store===''||!preg_match('/^[A-Za-z0-9._-]{1,80}$/',$store)){http_response_code(400);echo json_encode(['ok'=>false,'error'=>'Invalid Store ID']);exit;}return $store; }
function get_record($store){$f=POS_DATA_DIR.'/'.hash('sha256',$store).'.json';if(!file_exists($f))return null;return json_decode(file_get_contents($f),true);}
function put_record($store,$raw){$f=POS_DATA_DIR.'/'.hash('sha256',$store).'.json';$now=time();$record=json_encode(['updated_at'=>$now,'payload'=>$raw],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);if(file_put_contents($f,$record,LOCK_EX)===false)return false;return $now;}
function register_device($store,$id,$name){if($id==='')$id='UNKNOWN';$f=POS_DATA_DIR.'/devices_'.hash('sha256',$store).'.json';$a=file_exists($f)?json_decode(file_get_contents($f),true):[];if(!is_array($a))$a=[];$a[$id]=['device_id'=>$id,'device_name'=>$name,'last_seen'=>time()];file_put_contents($f,json_encode($a,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),LOCK_EX);return $a;}

$raw=file_get_contents('php://input');$body=json_decode($raw?:'{}',true);$action=$_GET['action']??($body['action']??'');
if($action==='register' || $action==='login'){
  $email=strtolower(trim($body['email']??''));$password=(string)($body['password']??'');$store=trim($body['store_id']??'');
  if(!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($password)<6){http_response_code(400);echo json_encode(['ok'=>false,'error'=>'Valid email and password (6+ chars) required']);exit;}
  $a=accounts();
  if($action==='register'){
    if(isset($a[$email])){http_response_code(409);echo json_encode(['ok'=>false,'error'=>'Account already exists']);exit;}
    $a[$email]=['password_hash'=>password_hash($password,PASSWORD_DEFAULT),'stores'=>[$store],'created_at'=>time()];save_accounts($a);
  } else {
    if(!isset($a[$email])||!password_verify($password,$a[$email]['password_hash'])){http_response_code(401);echo json_encode(['ok'=>false,'error'=>'Invalid email or password']);exit;}
    if($store!=='' && !in_array($store,$a[$email]['stores']??[],true)){ $a[$email]['stores'][]=$store;save_accounts($a); }
  }
  echo json_encode(['ok'=>true,'email'=>$email,'token'=>issue_token($email),'expires_in'=>86400*30]);exit;
}

$auth=auth_account();if(!$auth){http_response_code(401);echo json_encode(['ok'=>false,'error'=>'Unauthorized']);exit;}
$store=store_key();
if(!$auth['master']){
  $a=accounts();if(!isset($a[$auth['email']])){http_response_code(401);echo json_encode(['ok'=>false,'error'=>'Account not found']);exit;}
  if(!in_array($store,$a[$auth['email']]['stores']??[],true)){http_response_code(403);echo json_encode(['ok'=>false,'error'=>'Store is not linked to this account']);exit;}
}
$rec=get_record($store);

if($action==='devices'){
  $f=POS_DATA_DIR.'/devices_'.hash('sha256',$store).'.json';$devices=file_exists($f)?json_decode(file_get_contents($f),true):[];if(!is_array($devices))$devices=[];echo json_encode(['ok'=>true,'store_id'=>$store,'devices'=>array_values($devices),'updated_at'=>$rec['updated_at']??0],JSON_UNESCAPED_UNICODE);exit;
}
if($action==='summary'){
  if(!$rec){http_response_code(404);echo json_encode(['ok'=>false,'error'=>'No cloud data']);exit;}
  $p=json_decode($rec['payload'],true)?:[];$sales=$p['sales']??[];$products=$p['products']??[];$salesTotal=0;$debt=0;$low=0;
  foreach($sales as $r){$salesTotal+=(float)($r['total']??0);if(($r['payment']??'')==='Debt')$debt+=(float)($r['remaining']??0);}
  foreach($products as $r){if((int)($r['qty']??0)<=(int)($r['low']??3))$low++;}
  echo json_encode(['ok'=>true,'store_id'=>$store,'updated_at'=>$rec['updated_at']??0,'sales_total'=>$salesTotal,'sales_count'=>count($sales),'product_count'=>count($products),'low_stock'=>$low,'debt_remaining'=>$debt],JSON_UNESCAPED_UNICODE);exit;
}
if ($_SERVER['REQUEST_METHOD']==='POST') {
  if(strlen($raw)<2||strlen($raw)>20*1024*1024){http_response_code(413);echo json_encode(['ok'=>false,'error'=>'Invalid payload size']);exit;}
  json_decode($raw,true);if(json_last_error()!==JSON_ERROR_NONE){http_response_code(400);echo json_encode(['ok'=>false,'error'=>'Payload is not valid JSON']);exit;}
  $clientSyncedAt=(int)($_SERVER['HTTP_X_CLIENT_SYNCED_AT']??0);
  if($rec){$serverUpdated=(int)($rec['updated_at']??0);if($serverUpdated>$clientSyncedAt){http_response_code(409);echo json_encode(['ok'=>false,'error'=>'Cloud data is newer. Pull/review before uploading.','updated_at'=>$serverUpdated]);exit;}}
  $now=put_record($store,$raw);if($now===false){http_response_code(500);echo json_encode(['ok'=>false,'error'=>'Storage failed']);exit;}
  $did=$_SERVER['HTTP_X_DEVICE_ID']??'';$dname=$_SERVER['HTTP_X_DEVICE_NAME']??($_SERVER['HTTP_X_DEVICE_NAME']??'Android');register_device($store,$did,$dname);
  echo json_encode(['ok'=>true,'store_id'=>$store,'updated_at'=>$now,'account'=>$auth['email'],'device_id'=>$did],JSON_UNESCAPED_UNICODE);exit;
}
if($_SERVER['REQUEST_METHOD']==='GET'){
  if(!$rec){http_response_code(404);echo json_encode(['ok'=>false,'error'=>'No cloud data for this Store ID']);exit;}
  echo json_encode(['ok'=>true,'store_id'=>$store,'updated_at'=>$rec['updated_at']??0,'payload'=>$rec['payload']??''],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;
}
http_response_code(405);echo json_encode(['ok'=>false,'error'=>'Method not allowed']);
?>
