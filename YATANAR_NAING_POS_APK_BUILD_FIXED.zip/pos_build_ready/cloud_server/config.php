<?php
// Change this secret before deployment.
const POS_CLOUD_TOKEN = 'CHANGE_THIS_TO_A_LONG_RANDOM_SECRET';
const POS_DATA_DIR = __DIR__ . '/data';
?>
