# YATANAR NAING MINI MARKET POS — Cloud Server Starter

This is the cloud API starter bundled with the Final Release development package.

It supports the POS client's account/device/sync flow, but it is NOT a hosted production service.

## Production requirements
- PHP 8+ on a real HTTPS server
- Production database instead of file-based JSON storage
- Strong secret management (never use the sample secret)
- Password hashing and secure token/session handling
- Rate limiting and abuse protection
- Account recovery and email verification where appropriate
- Encryption at rest for sensitive backups
- Automated server backups and restore testing
- Monitoring, logging and alerting
- Strict filesystem permissions and private data storage

## Important
Do not expose the starter endpoint publicly with its sample configuration. Treat cloud backups as sensitive business data.
