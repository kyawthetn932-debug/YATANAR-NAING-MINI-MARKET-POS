# YATANAR NAING POS V1.4

V1.4 extends the V1.3 source project.

## New: Purchase Invoice OCR -> Editable Stock-In
- Invoice photo can be selected from Camera or Gallery.
- OCR text is shown for review.
- A parser attempts to turn lines containing quantity + price into editable product rows.
- Each row has Product Name, Barcode, Category, Qty and Purchase Price.
- Existing products are matched by barcode or exact product name when stock-in is confirmed.
- Existing product stock increases and purchase price is updated.
- New products are created with a temporary unique barcode when no barcode is supplied.
- Category is auto-suggested for common English product names; user can edit it before confirmation.
- Invoice header stores Supplier, invoice phone, DD/MM/YYYY date, OCR text and photo URI when available.
- Invoice item history is stored separately.
- Stock is changed only after the user presses the confirmation button.

## Important
OCR can misread invoices, and the current ML Kit dependency is Latin text recognition. Burmese invoice OCR may require a stronger OCR engine later. Always review Name / Qty / Purchase Price / Category before confirming Stock-In.

## Existing foundation retained
Sales, stock, barcode duplicate prevention, low-stock alert, customer/supplier contact, phone-call action, WavePay/KBZPay/Cash/Debt recording, and invoice OCR screen.

## Build note
This ZIP is Android source code. An APK/AAB is not included because the current build environment does not have the Android SDK/Gradle toolchain installed.
