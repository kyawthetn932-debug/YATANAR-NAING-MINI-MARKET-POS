# YATANAR NAING POS V3.3

V3.3 extends V3.2 Cloud Sync with a deployable PHP HTTPS server starter and a Cloud Pull function.

## New
- ☁️ Cloud Data Pull / owner phone can retrieve the latest store backup.
- Store ID + Bearer token authentication.
- HTTPS-only client check.
- Cloud server starter under `cloud_server/`.
- Version code 13 / version 3.3.

## Limitation
This is a starter cloud backup/sync architecture, not a finished production SaaS backend. The starter stores the POS JSON backup on the server and V3.3 Pull replaces local data. Production should add a real database, encryption at rest, per-account authentication, conflict resolution, audit-safe append-only logs, rate limiting, monitoring, automated backups and a privacy policy.
