# YATANAR NAING POS V2.0

## 🔐 Owner / Staff Login + Permission + Audit Log

V2.0 builds on V1.9 and adds a first security layer for the Mini Market POS.

### Login
- Owner: PIN `1234` (initial default)
- Staff: PIN `0000` (initial default)
- PINs are stored as SHA-256 hashes in the local SQLite database.
- Owner can change the PIN after login.

### Permissions
- Owner: all current modules, including Pricing, Reports, Demand Analysis, Audit Log and Owner Settings.
- Staff: Sales, Product/Stock, Customer/Supplier contact, Invoice OCR/Stock-In and Debt Ledger.
- Owner-only modules are blocked for Staff and a denied-access event is logged.

### Audit Log
Records include:
- date/time (DD/MM/YYYY HH:mm)
- username
- role
- action
- details

Examples: LOGIN, LOGOUT, OPEN, SAVE, SALE, STOCK_IN, CHANGE_PIN, DENIED.

### Database
- Database version: 7
- Adds `users` and `audit_logs` tables.
- Existing V1.9 databases are upgraded with `onUpgrade`.

### Notes
- This is a source project ZIP, not an APK.
- Android SDK/Gradle build tools are not available in the current build environment, so an APK cannot be compiled here.
- Initial PINs should be changed by the owner before real store use.
