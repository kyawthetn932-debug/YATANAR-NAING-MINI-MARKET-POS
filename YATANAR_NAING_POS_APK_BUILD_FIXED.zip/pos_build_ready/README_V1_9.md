# YATANAR NAING POS V1.9

## 📈 ဝယ်လိုအား / ရောင်းအား Analysis
- ယခုလနှင့် ယခင်လ ရောင်းအား quantity နှိုင်းယှဉ်မှု
- Best Seller / ရောင်းအားတက်လာသောပစ္စည်း
- Slow Moving / 30 ရက်အတွင်း ရောင်းအားမရှိသောပစ္စည်း
- Reorder Alert: 30 ရက်ပျမ်းမျှရောင်းအားအပေါ်မူတည်ပြီး လက်ကျန်ခန့်မှန်းရက်
- Low Stock threshold ကို product တစ်ခုချင်းစီ၏ low field ဖြင့်အသုံးပြုသည်
- DD/MM/YYYY ရက်စွဲ

V1.9 သည် V1.8 source project ကိုအခြေခံထားသည်။ APK မဟုတ်ပါ။
