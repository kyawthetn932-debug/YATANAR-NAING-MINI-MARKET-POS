# YATANAR NAING POS — V1.2

ဆက်လက်တည်ဆောက်ထားသောအပိုင်း — Sales / အရောင်းစနစ်

ပါဝင်သည်:
- Barcode / Product Code ဖြင့် ပစ္စည်းရှာခြင်း
- Quantity ထည့်ခြင်း
- Stock မလုံလောက်ပါက ရောင်းမရ
- Cart ထဲသို့ ပစ္စည်းများစုခြင်း
- Total အလိုအလျောက်တွက်ခြင်း
- Cash / WavePay / KBZPay / Debt payment ရွေးခြင်း
- Sale record သိမ်းခြင်း
- ရောင်းပြီးသော quantity ကို Stock မှ အလိုအလျောက်လျော့ခြင်း
- Product barcode duplicate prevention
- Low Stock threshold (default 3)
- Supplier / Customer contact + phone dial

နောက်ဆင့်အစီအစဉ်:
1. Purchase invoice + Camera/OCR + Supplier linking
2. Pricing + transport cost allocation by item value
3. Debt ledger + payment history
4. Receipt / printer
5. Reports / profit & loss
6. Owner/Staff lock + audit log
7. Cloud / multi-device

မှတ်ချက်: ဒီဖိုင်သည် source project ဖြစ်ပြီး ဒီ runtime မှာ Android SDK/Gradle build tools မရှိသောကြောင့် APK မဟုတ်သေးပါ။
