# YATANAR NAING MINI MARKET POS — V2.9

V2.9 continues from V2.8 and prepares the POS for final production work.

## Added / improved
- Version code/name updated to 9 / 2.9.
- Cash checkout now asks for Cash Tendered and calculates Change.
- Cash tendered and change are included in the generated receipt text.
- Existing Owner/Staff permissions, audit log, store settings, backup foundation, stock movement, barcode/photo, OCR, pricing, sales, debt, reports, demand analysis and receipt history are retained.

## Important
Cloud sync is still a foundation/backup workflow, not a live Internet server sync. WavePay/KBZPay are recorded payment methods; direct API payment requires merchant/provider credentials and approval. Printer support remains Android Print Framework/Bluetooth foundation until a specific ESC/POS printer model is selected.

Next production stage should focus on real cloud backend/authentication, hardware-specific thermal/barcode printing, security testing, migration testing, signed AAB build and Play Store release preparation.
